﻿# Nota sobre esta cópia

Esta é uma cópia do Ricks Clips Style Kit, de @caesarscales, distribuída sob a licença MIT (veja o arquivo LICENSE).

Em relação ao arquivo original, foram retirados apenas materiais de terceiros que acompanhavam o kit como estudo:

- as folhas de quadros de vídeos de outros canais em `reference/` (arquivos de imagem);
- as transcrições de vídeos de outros canais (`reference/ricks-study/data/scripts.txt` e `reference/triple_hook_transcript.txt`);
- a folha de comparação `characters/sheets/faces_vs_ricks.jpg`, que contém quadros de vídeos de terceiros.

Esses materiais pertencem aos criadores dos vídeos. O código, os documentos, as medições numéricas e a licença estão completos.
Onde os documentos mandarem comparar com `reference/ricks-study/`, use as medições em `reference/ricks-study/data/` e os relatórios em `reference/kit-reports/`.

Recomendação de quem republicou: use o motor e o método, e crie elenco, paleta e histórias próprios.
